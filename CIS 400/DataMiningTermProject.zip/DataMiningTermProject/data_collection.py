from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import pandas as pd

analyzer = SentimentIntensityAnalyzer()

def categorize_comment(comment):
    # Define keywords
    democrat_keywords = ["Kamala", "Harris", "Biden", "Democrat", "liberal", "progressive"]
    republican_keywords = ["Trump", "Vance", "MAGA", "Republican", "GOP", "conservative"]

    # Perform sentiment analysis
    sentiment_score = analyzer.polarity_scores(comment)['compound']

    # Categorize based on sentiment and keywords
    if any(keyword.lower() in comment.lower() for keyword in republican_keywords):
        if sentiment_score > 0.05:
            return "Republican"
        elif sentiment_score < -0.05:
            return "Democrat"
        else:
            return "Neutral-Republican"
    elif any(keyword.lower() in comment.lower() for keyword in democrat_keywords):
        if sentiment_score > 0.05:
            return "Democrat"
        elif sentiment_score < -0.05:
            return "Republican"
        else:
            return "Neutral-Democrat"

    return "Neutral"  # No clear sentiment or mention

def collect_and_categorize_comments(reddit, subreddit_name, keyword, num_threads=5, num_comments=100):
    subreddit = reddit.subreddit(subreddit_name)
    comments = []

    for submission in subreddit.search(keyword, limit=num_threads):
        submission.comments.replace_more(limit=0)
        for comment in submission.comments.list()[:num_comments]:
            category = categorize_comment(comment.body)
            comments.append({"comment": comment.body, "category": category})

    return pd.DataFrame(comments)

if __name__ == "__main__":
    from auth import get_reddit_instance

    reddit = get_reddit_instance()
    data = collect_and_categorize_comments(reddit, "politics", "Trump", num_threads=5, num_comments=100)
    data.to_csv("data/categorized_comments.csv", index=False)
