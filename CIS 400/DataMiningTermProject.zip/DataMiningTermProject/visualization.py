import nltk
import ssl
from nltk.corpus import stopwords
from collections import Counter
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

# Fix SSL issue for downloading NLTK data
try:
    _create_default_https_context = ssl._create_default_https_context
    ssl._create_default_https_context = ssl._create_unverified_context
    nltk.download('stopwords')
finally:
    ssl._create_default_https_context = _create_default_https_context

def generate_category_pie_chart(data, title):
    sentiment_counts = data['sentiment_category'].value_counts()
    plt.figure()
    plt.pie(
        sentiment_counts,
        labels=sentiment_counts.index,
        autopct='%1.1f%%'
    )
    plt.title(title)

def generate_word_frequency_bar_chart(data, title):
    stop_words = set(stopwords.words('english'))
    all_words = ' '.join(data['comment']).split()
    filtered_words = [word for word in all_words if word not in stop_words]
    word_counts = Counter(filtered_words).most_common(10)

    if len(word_counts) == 0:
        print(f"No words found for {title}.")
        return

    words, counts = zip(*word_counts)
    plt.figure()
    plt.bar(words, counts)
    plt.title(title)
    plt.xlabel('Words')
    plt.ylabel('Counts')

def save_visualizations_to_pdf(file_path, sentiment_data_path):
    df = pd.read_csv(sentiment_data_path)

    # Separate data by category
    democrat_data = df[df['category'] == 'Democrat']
    republican_data = df[df['category'] == 'Republican']

    with PdfPages(file_path) as pdf:
        # Generate pie charts
        print("Generating Democrat pie chart...")
        generate_category_pie_chart(democrat_data, 'Democrat Sentiment Analysis Breakdown')
        pdf.savefig()  # Save current figure to PDF
        plt.close()

        print("Generating Republican pie chart...")
        generate_category_pie_chart(republican_data, 'Republican Sentiment Analysis Breakdown')
        pdf.savefig()  # Save current figure to PDF
        plt.close()

        # Generate bar charts
        print("Generating Democrat bar chart...")
        generate_word_frequency_bar_chart(democrat_data, 'Most Common Words - Democrats')
        pdf.savefig()  # Save current figure to PDF
        plt.close()

        print("Generating Republican bar chart...")
        generate_word_frequency_bar_chart(republican_data, 'Most Common Words - Republicans')
        pdf.savefig()  # Save current figure to PDF
        plt.close()

        print(f"All visualizations saved to {file_path}.")

if __name__ == "__main__":
    save_visualizations_to_pdf(
        "results/visualizations.pdf",
        "data/sentiment_categorized_comments.csv"
    )
